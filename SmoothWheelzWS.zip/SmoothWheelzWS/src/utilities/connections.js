const { Schema } = require("mongoose");
var Mongoose = require("mongoose")
Mongoose.Promise = global.Promise;
var url = "mongodb://localhost:27017/rentals_DB";


var RentalSchema = Schema({
    name: String,
    customerId: Number,
    location: String,
    emailId: String,
    rent: [{
        rentId: Number,
        vehicleType: String,
        rentDate: Date,
        duration: Number,
        rentAmount: Number
    }]
}, { collection: "Rental" })


var collection = {};

collection.getCollection = () => {
    return Mongoose.connect(url,{ useNewUrlParser: true }).then( (database)=> {
        return database.model('Rental', RentalSchema)
    }).catch((error) => {
        let err= new Error("Could not connect to Database");
        err.status = 500;
        throw err;
    })
}


module.exports = collection;
