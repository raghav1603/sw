import React, { Component } from 'react';

// Import the required module(s) here

import axios from "axios";

const ridesURL = "http://localhost:2500/rent/";



class View extends Component {

    constructor(props) {

        super(props);

        this.state = {

            customerId: "",

            selectedRides: [],

            errorMessage: ""

        }

    }



    handleChange = (event) => {

        /* 

            invoke whenever any change happens in customerId field

            and update customerId state with the value

        */

        const target = event.target;

        const value = target.value;

        // const name = target.name;





        this.setState({ customerId: value });



    }



    fetchRides = () => {

        /*

            This method should sent an AXIOS GET request to the URL http://localhost:2500/rent/:customerId

            and fetch all the ride details for the customerId 

            and then handle the success and error cases appropriately

        */



        this.setState({ errorMessage: "" })

        axios.get(ridesURL + this.state.customerId)

            .then(response => {

                // console.log(response.data)

                this.setState({ selectedRides: response.data, errorMessage: "" })

            })

            .catch(error => {



                if (error) {

                    this.setState({ selectedRides: [], errorMessage: error.response.data.message })

                } else {

                    this.setState({ selectedRides: [], errorMessage: "server error" })

                }

            })



    }



    displayRides = () => {

        /*

           This method should create an array of <tr> tags to be displayed in the 

           table vehicle ride details for the mentioned customerId

           Finally an array of such rows for each ride detail should be returned

       */

        let arr = [];

        const ele = (

            <tr>

                <th>vehicleType</th>

                <th>Rent Date</th>

                <th>Duration</th>

                <th>Rent Amount</th>

            </tr>

        )

        arr.push(ele)

        this.state.selectedRides.map((ele => {

            let date = new Date(ele.rentDate);

           let vehicle=""

            if(ele.vehicleType=="2Wheeler")

            {

                vehicle="Two Wheeler"

            }

            if(ele.vehicleType=="4Wheeler")

            {

                vehicle="Four Wheeler"

            }

            let com = (

                < tr key={ele.rentId} >

                    <td>{vehicle}</td>

                    <td>{date.toDateString()}</td>

                    <td>{ele.duration} Hours</td>

                    <td>Rs: {ele.rentAmount}</td>

                </tr >

            )

            arr.push(com);

        }))

        return arr

    }



    render() {

       

        return (

            <div> <br />

                <div className="row">

                    <div className="col-md-6 offset-3">

                        <div className="card">

                            <div className="card-header text-light bg-dark">

                                <h4 className="text-center">Ride Details</h4>

                            </div>



                            {/* code the JSX here to render the view as shown in QP */}



<div className="card-body text-light bg-dark">



                            { this.state.selectedRides.length!=0 ?

                                (

                                <div>

                                   

                                    <table className="table text-light table-dark">

                                        {this.displayRides()}

                                        <button type="button" className="btn btn-danger" onClick={() => {

                                            this.setState({ selectedRides: [] })

                                        }}>Close</button></table>

                                </div>) : (

                                    <div className="card-body text-light bg-dark">

                                    

                                        <div className="form-group">

                                            <label>customer Id</label>

                                            <input className="card container-fluid"

                                                name="customerId"

                                                id="customerId"

                                                placeholder="Enter your customer id"

                                                onChange={this.handleChange}

                                            />

                                            <br />

                                            <button type="button"

                                                name="showRides"

                                                className="btn btn-primary"

                                                onClick={this.fetchRides}

                                            >Show Rides</button>

                                        </div>

                                    </div>

                                )

                            }

                            <span name="errorMessage" className="text-danger text-bold">

                                {this.state.errorMessage}

                            </span>



                        </div></div>

                    </div>

                </div >

            </div >

        )

    }

}



export default View;
