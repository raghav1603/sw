import React, { Component } from 'react'
// Import the necessary modules (if any needed) here
import axios from "axios";
const rentURL = "http://localhost:2500/rent/";

class Rent extends Component {
    constructor() {
        super();
        this.state = {
            rentForm: {
                customerId: "",
                rentDate: "",
                duration: "",
                vehicleType: ""
            },
            formErrorMessage: {
                customerId: "",
                rentDate: "",
                duration: "",
                vehicleType: ""
            },
            formValid: {
                customerId: false,
                rentDate: false,
                duration: false,
                vehicleType: false,
                buttonActive: false
            },
            successMessage: "",
            errorMessage: ""
        }
    }

    handleChange = (event) => {
        /* 
            invoke whenever any change happens in any of the input fields
            and update form state with the value. Also, Invoke validateField() method to validate the entered value
        */
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const { rentForm } = this.state;

        this.setState({ rentForm: { ...rentForm, [name]: value } });
        // console.log(this.state.rentForm)
        this.validateField(name, value);
    }

    validateField = (fieldName, value) => {
        /* 
        * Perform Validations and assign error messages, Also, 
        * set the value of buttonActive after validation of the field 
        */
        let tempValid = this.state.formValid;
        let tempError = this.state.formErrorMessage;
        let stringVal = String(value);
        let currDate = new Date();
        let gdate = new Date(value);
        switch (fieldName) {
            case "customerId":
                if (value === "") {
                    tempError.customerId = "field required";
                    tempValid.customerId = false;
                }
                else if (stringVal.length !== 6 || stringVal[0] !== "6") {

                    tempError.customerId = "Customer Id should start with 6 and should be a 6 digit number"
                    tempValid.customerId = false
                }
                else {
                    tempError.customerId = " ";
                    tempValid.customerId = true;
                }
                break;
            case "rentDate":
                if (value === "") {
                    tempError.rentDate = "Field Required";
                    tempValid.rentDate = false;
                }
                else if (currDate > gdate) {

                    tempError.rentDate = "Rent date cannot be before current date";
                    tempValid.rentDate = false;
                }
                else {
                    tempError.rentDate = " ";
                    tempValid.rentDate = true;
                }
                break;
            case "duration":
                if (value == "") {
                    tempError.duration = "Field Required";
                    tempValid.duration = false;
                }
                else if (value < 1) {
                    tempError.duration = "Duration of rent cannot be less than 1 Hour"
                    tempValid.duration = false
                }
                else {
                    tempError.duration = " ";
                    tempValid.duration = true
                }
                break;

            default:
                break;
        }
        tempValid.buttonActive =
            tempValid.rentDate &&
            tempValid.duration &&
            tempValid.customerId

        this.setState({ formErrorMessage: tempError, formValid: tempValid, successMessage: ' ' })
    }

    rentVehicle = (event) => {
        /* 
            Prevent page refresh on form submission and
            Make aN axios PUT request to http://localhost:2500/bookMobile/:customerId with form data 
            and handle success and error cases 
        */
        event.preventDefault();
        this.setState({ errorMessage: "", successMessage: "" })

        axios.put(rentURL + this.state.rentForm.customerId, this.state.rentForm)
            .then(response => {
               
                this.setState({ successMessage: response.data.message, errorMessage: "" });
            }).catch(error => {
                if (error.response) {
                    this.setState({ errorMessage: error.response.data.message })
                } else {
                    this.setState({ errorMessage: "server error" })
                }
            })
    }

    render() {
        return (
            <div className="Rent"><br />
                <div className="row">
                    <div className="col-md-4 offset-4">
                        <div className="card bg-dark text-light">
                            <div className="card-header">
                                <h4>Vehicle Rental Form</h4>
                            </div>
                            <div className="card-body text-left">
                                {/* create form as per the view given in screenshots */}
                                {/* Display success or error messages as given in QP */}
                                <form className='rentVehicle' onSubmit={this.rentVehicle}>
                                    <div className="form-group">
                                        <label htmlFor="customerId">Customer ID </label>
                                        <input
                                            type="text"
                                            name="customerId"
                                            id="customerId"
                                            placeholder="Enter valid customer id"
                                            // value={this.state.formValue.customerName}
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />

                                        <span name="customerIdError" className="text-danger">
                                            {this.state.formErrorMessage.customerId}
                                        </span>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="vehicleType">Vehicle Type </label>

                                        <input type="radio" name="vehicleType" value="2Wheeler" onChange={this.handleChange} style={{ margin: 10 }} />Two Wheeler
                                        <input type="radio" name="vehicleType" value="4Wheeler" onChange={this.handleChange} style={{ margin: 10 }} />Four Wheeler
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="rentDate">Rent Date </label>
                                        <input
                                            type="date"
                                            name="rentDate"
                                            id="rentDate"
                                            placeholder="mm/dd/yyyy"
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />

                                        <span name="rentDateError" className="text-danger">
                                            {this.state.formErrorMessage.rentDate}
                                        </span>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="duration">Duration </label>
                                        <input
                                            type="number"
                                            name="duration"
                                            id="duration"
                                            placeholder="Enter duration in hour"
                                            // value={this.state.formValue.customerName}
                                            onChange={this.handleChange}
                                            className="form-control"
                                        />

                                        <span name="durationError" className="text-danger">
                                            {this.state.formErrorMessage.duration}
                                        </span>
                                    </div>
                                    <button type="submit" className="btn btn-primary" name="bookRide"
                                        disabled={!this.state.formValid.buttonActive}>Book Ride</button>
                                </form>
                                <br />
                                <span name="successMessage" className="text-success text-bold">
                                    {this.state.successMessage}
                                </span>
                                <span name="errorMessage" className="text-danger text-bold">
                                    {this.state.errorMessage}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Rent;