var model = require('../model/user');
var Validator = require('../utilities/validator');
const exec = require('child-process-promise').exec;
const fs = require('fs');
const path = require("path")
const parser = require("./parser");

var rentalService = {}

rentalService.evaluate = () => {
    evaluationPath = path.join(__dirname, "../../../smooth-wheelz");
    console.log("Begin testing!!");
    return exec(`cd ${evaluationPath} && npm test`)
        .then((response) => {
            let content = fs.readFileSync("../../smooth-wheelz/result.json", 'utf8');
            return parser.generateTestReport(content);
        }).catch((err) => {
            let content = fs.readFileSync("../../smooth-wheelz/result.json", 'utf8');
            return parser.generateTestReport(content);
        })
}

rentalService.calculateRent = (vehicleObj) => {
    if (vehicleObj.vehicleType == "4Wheeler") {
        vehicleObj.rentAmount = 100 * vehicleObj.duration;
    } else if (vehicleObj.vehicleType == "2Wheeler") {
        vehicleObj.rentAmount = 50 * vehicleObj.duration;
    } else {
        let err = new Error("Invalid vehicle type");
        err.status = 400;
        throw err;
    }
}


rentalService.getCustomer = (customerId) => {
    return model.customerDetails(customerId).then((customer) => {
        if (customer == null) {
            let err = new Error("Customer details not found");
            err.status = 404;
            throw err;
        } else {
            return customer
        }
    })
}


rentalService.rent = (customerId, vehicle) => {
    Validator.validateCustomer(customerId);
    Validator.validateDate(vehicle.rentDate);
    
    return rentalService.getCustomer(customerId).then((customer) => {
        rentalService.calculateRent(vehicle);
        return model.rentVehicle(customerId,vehicle);
    }).then((vehicle) => {
        if (vehicle) {
            return vehicle
        } else {
            let err = new Error("Failed to update data")
            err.status = 500;
            throw err;
        }
    })
}

rentalService.getRentals = (customerId) => {
    Validator.validateCustomer(customerId);
    return rentalService.getCustomer(customerId).then((data) => {
        if (data.rent.length > 0) {
            return data.rent
        } else {
            let err = new Error("No rental vehicles had been taken")
            err.status = 404
            throw err;
        }
    })
}

module.exports = rentalService;